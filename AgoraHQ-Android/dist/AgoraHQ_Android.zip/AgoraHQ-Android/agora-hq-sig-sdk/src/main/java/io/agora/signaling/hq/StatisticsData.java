package io.agora.signaling.hq;

/**
 * Created by Yao Ximing on 2018/1/17.
 */

public class StatisticsData {
    public static StatisticsItem statisticsItem;
}

//
//  KeyCenter.swift
//  AgoraHQ
//
//  Created by ZhangJi on 08/01/2018.
//  Copyright © 2018 ZhangJi. All rights reserved.
//

struct KeyCenter {
    static let AppId: String = "363f97d9690e4c0a9780499ab14a16c0"
    // if the App Certificate is not opened, Fill in AppcertificateID with ""
    static let AppcertificateID:  String = ""
}

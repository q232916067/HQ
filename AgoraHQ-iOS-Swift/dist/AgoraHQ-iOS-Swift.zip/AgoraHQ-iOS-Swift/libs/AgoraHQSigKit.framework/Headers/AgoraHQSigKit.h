//
//  AgoraHQSigKit.h
//  AgoraHQSigKit
//
//  Created by suleyu on 2018/1/13.
//  Copyright © 2018 Agora. All rights reserved.
//

#define AGORA_HQ_SIG_SDK_VERSION @"1.0.1"

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSErrorDomain const AgoraHQErrorDomain;

typedef NS_ENUM(NSInteger, AgoraHQErrorCode) {
    AgoraHQErrorCodeNoError = 0,
    AgoraHQErrorCodeMessageSendError = 1,
    AgoraHQErrorCodeTokenInvalid = 2,
    AgoraHQErrorCodeTokenExpired = 3,
    AgoraHQErrorCodeLoginFailed = 4,
    AgoraHQErrorCodeKicked = 5,
    AgoraHQErrorCodeOnBlackList = 6,
    AgoraHQErrorCodeNoConnection = 7,
    AgoraHQErrorCodeConnectionFailed = 8
};

@class AgoraHQSigKit;
@protocol AgoraHQSigDelegate<NSObject>

- (void)agoraHQSigDidLoginSuccess:(AgoraHQSigKit *)agoraHQSig;

@optional

- (void)agoraHQSig:(AgoraHQSigKit *)agoraHQSig didReceivedChannelMessage:(NSString *)channel message:(NSString *)message messageId:(long long)messageId;

- (void)agoraHQSig:(AgoraHQSigKit *)agoraHQSig didReceivedMessageFromAccount:(NSString *)account message:(NSString *)message messageId:(long long)messageId;

- (void)agoraHQSig:(AgoraHQSigKit *)agoraHQSi didOccurError:(NSError *)error;

@end

@interface AgoraHQSigKit : NSObject

@property (nonatomic, weak) id<AgoraHQSigDelegate> delegate;

+ (instancetype)sharedInstance;

- (instancetype)initWithAppId:(NSString *)appId;

- (void)login:(NSString *)account token:(NSString *)token channel:(NSString *)channel;

- (void)dbg:(NSString*)a b:(NSString*)b;

- (BOOL)sendChannelMessage:(NSString *)message messageId:(long long)messageId;

- (BOOL)sendMessageToAccount:(NSString *)account message:(NSString *)message messageId:(long long)messageId;

- (void)logout;

@end


